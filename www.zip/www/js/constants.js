angular.module('starter')

     
	 .constant('BASE_URL','http://localhost/hotsys/public');
      //.constant('BASE_URL','http://192.168.0.101/hotsys/public');
        //.constant('BASE_URL','http://bluesys.in/dev/messaging_app/public'); 
        //.contant('TOKEN',localStorage.getItem('token'));